export const s3config = {
    accessKeyId: 'AKIAJB7R6W7Q7UWR3FHA', 
    secretAccessKey: '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', 
    region: 'eu-west-1'
}
