export interface IEnvironment {
    name: string;
    workLoadType: string;
    instanceType: string;
    instanceSize: string;
}