export class File {
    name: string;
    lastModified: string;
    constructor(name: string, lastModified: string){
        this.name = name;
        this.lastModified = lastModified;
    }
}