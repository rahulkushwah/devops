export const environment = {
  production: true,
  baseUrl: 'http://10.141.29.41:8080'
};
