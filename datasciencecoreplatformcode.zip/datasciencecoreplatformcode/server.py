import ssl
import ldap3
from flask import Flask, render_template, flash, redirect, url_for, session, app, request, logging, Response , jsonify
import sys
import json
from flask_cors import CORS, cross_origin

sys.path.append('environment')

from ClusterManagementUI import ClusterManagementUI
from UserManagementUI import UserManagementUI


VPC="vpc-02034c65"
SubnetId="subnet-d754d08c"
key="data_science_platform_dev_pair"
AMI="ami-0dca662db75b46b76"
Sg="sg-039b42a25f330bb1f"
SgBasts="sg-7eeeb905"
awsenv = "dev"
appenv = "dev"
reg = "eu-west-1"
app = Flask(__name__)

cors = CORS(app, resources={r"/*": {"origins": "*"}})

# Health Check
@app.route('/health', methods=['GET'])
def getHealth():
    return jsonify("I am Working")


# UI Render Data

@app.route('/getUIData', methods=['GET', 'POST'])
def getUIData():
    with open('UIDATA.json', 'r') as f:
            uiData = json.load(f)
    return jsonify(uiData)

@app.route('/getUIUserData', methods=['GET', 'POST'])
def getUIUserData():
    with open('UIUSERDATA.json', 'r') as f:
            uiData = json.load(f)
    return jsonify(uiData)
	
# User login
@app.route('/login', methods=['GET', 'POST'])
def login():
    return {"login":"True","group":"test"}
    if request.method == 'POST':
        # Get Form Fields
        username = request.json['username']
        password_candidate = request.json['password']
        validResponse={}
        server = ldap3.Server('ldapad.lmig.com', get_info=ldap3.ALL)
        conn = ldap3.Connection('ldap://ldapad.lmig.com:389', 'sacip_lmb_hdp_np_adm@lm.lmig.com', ldapcred, auto_bind=True)
        tls_configuration = ldap3.Tls(validate=ssl.CERT_REQUIRED, version=ssl.PROTOCOL_TLSv1)
        conn.bind()
        conn.search(search_base='dc=lm,dc=lmig,dc=com', search_filter='(UserPrincipalName=' + username + '*)', search_scope=ldap3.SUBTREE, attributes=['distinguishedName'], paged_size=5)
        userDN = conn.response[0]['dn']
        conn1 = ldap3.Connection(server, user=userDN, password=password_candidate)
        if(conn1.bind()):
            conn.search(search_base='dc=lm,dc=lmig,dc=com', search_filter='(UserPrincipalName=' + username + '*)', search_scope=ldap3.SUBTREE, attributes=['memberOf'], paged_size=5)
            groups = conn.response[0]['attributes']['memberOf']
            authorized_group = 'CN=gci-lmb-datascience-users,OU=Infrastructure,OU=Security,OU=LM Groups,DC=lm,DC=lmig,DC=com'
            logged_in_admin = False
            if authorized_group in groups:
                logged_in = True
                admin_group = 'CN=gci-lmb-datascience-admin,OU=Infrastructure,OU=Security,OU=LM Groups,DC=lm,DC=lmig,DC=com'
                if admin_group in groups:
                    logged_in_admin = True
                validResponse['login'] = logged_in
                if logged_in_admin:
                    validResponse['group'] = 'admin'
                else:
                    validResponse['group'] = 'user'
                # flash('You are now logged in', 'success')
                return validResponse
            else:
                validResponse['login'] = False
                validResponse['group'] = 'you are not in Data science group'
                return validResponse
        else:
            validResponse['login'] = False
            validResponse['group'] = 'you are not in Data science group'
            return validResponse

@app.route('/createUser', methods=['POST'])
def create_user():
    response = ''
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            username = request.json['newUserDetails']['username']
            newUserId = request.json['newUserDetails']['userId']
            email = request.json['newUserDetails']['email']
            role = request.json['newUserDetails']['group']
            #role = request.json['newUserDetails']['role']
            bucketList = request.json['newUserDetails']['s3bucketlist']
            userAdd = UserManagementUI(newUserId, awsenv, appenv, reg)
            userAdd.createFolder(newUserId)
            roleName = userAdd.createRoleCft(bucketList, newUserId)
            clusterName= userAdd.createCluster(newUserId,reg)
            if(userAdd.addToDatabase(newUserId,email,username,roleName,role,clusterName)):
                response = "User has been created."
            else:
                response = "User creation failed."
        except Exception as e:
            response = "User creation failed."

    return jsonify(response)

@app.route('/getUserClusters' , methods=['POST'])
def getUserClusters():
    if request.headers['Content-Type'] == 'application/json':
        try:
            nId = request.json['userId']
        except:
            return('Please check if you have included all inputs!')
        clusterManagementUI = ClusterManagementUI(nId,awsenv,appenv,reg)
        return jsonify(clusterManagementUI.getClusterDetails(nId))
    else:
        return(" Wrong Input")


@app.route('/createCluster', methods=['POST'])
def createCluster():
    if request.headers['Content-Type'] == 'application/json':
        try:
            print(request.json)
            nId = request.json['userId']
            type = request.json['type']
            volumeSize = request.json['volumeSize']
            userClusterName = request.json['userClusterName']
            if type =='DOCKER':
                return "working on it"
            elif type == 'EMR':
                print ('in EMR')
                workloadType = request.json['workloadType']
                instanceType = request.json['instanceType']
                instanceSize = request.json['instanceSize']
                instanceCount = request.json['nodeCount']
                volumeSize = request.json['volumeSize']
                userClusterName = request.json['userClusterName']
                clusterManager = ClusterManagementUI(nId, awsenv, appenv, reg)
                response = clusterManager.createEMRCluster(workloadType, instanceType, instanceSize, instanceCount,volumeSize,userClusterName)

            else:
                workloadType = request.json['workloadType']
                instanceType = request.json['instanceType']
                instanceSize = request.json['instanceSize']
                volumeSize = request.json['volumeSize']
                userClusterName = request.json['userClusterName']
                image = request.json['image']
                clusterManager = ClusterManagementUI(nId,awsenv,appenv,reg)
                response = clusterManager.createECSCluster(workloadType,instanceType,instanceSize,image,volumeSize,userClusterName)
        except Exception as e:
            print (e)
            return ('Please check if you have included all inputs!')
        return jsonify(response)




@app.route('/getAllUsers', methods=['POST'])
def getAllUsers():
    if request.headers['Content-Type'] == 'application/json':
        try:
            nId = request.json['userId']
            userManagement = UserManagementUI(nId,awsenv,appenv,reg)
            response = userManagement.getAllUsers()
        except Exception as e:
            return ('Please check if you have included all inputs!')
        return jsonify(response)


@app.route('/startCluster', methods=['POST'])
def startCluster():
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterId = request.json['clusterName']
            userId=findifadmin(clusterId, userId)
            clusterManagement = ClusterManagementUI(userId,awsenv,appenv,reg)
            response = clusterManagement.startCluster(userId,clusterId)
        except Exception as e:
            return ('Please check if you have included all inputs!')
        return jsonify(response)


@app.route('/stopCluster', methods=['POST'])
def stopCluster():
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterId = request.json['clusterName']
            userId=findifadmin(clusterId, userId)
            clusterManagement = ClusterManagementUI(userId,awsenv,appenv,reg)
            response = clusterManagement.stopCluster(userId,clusterId)
        except Exception as e:
            return ('Please check if you have included all inputs!')
        return jsonify(response)


@app.route('/deleteCluster', methods=['POST'])
def deleteCluster():
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterId = request.json['clusterName']
            userId=findifadmin(clusterId, userId)
            clusterManagement = ClusterManagementUI(userId,awsenv,appenv,reg)
            response = clusterManagement.deleteCluster(userId,clusterId)
        except Exception as e:
            return ('Please check if you have included all inputs!')
        return jsonify(response)


@app.route('/deleteUser', methods=['POST'])
def deleteUser():
    response = ''
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            deleteUserId = request.json['deleteUserDetails']['userId']
            usermanagement = UserManagementUI(deleteUserId, awsenv, appenv, reg)
            response = usermanagement.deleteUser(deleteUserId)
        except:
            response = "error in deleting user."
            return response

    return jsonify(response)

@app.route('/getAllCluster', methods=['POST'])
def getAllCluster():
    response = ''
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterManagement = ClusterManagementUI(userId, awsenv, appenv, reg)
            response = clusterManagement.getAllCluster()
        except:
            response = "error in getting all cluster."
            return response

    return jsonify(response)

@app.route('/getLogs', methods=['POST'])
def getLogs():
    response = ''
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterManagement = ClusterManagementUI(userId, awsenv, appenv, reg)
            response = clusterManagement.getLogs(userId)
        except:
            response = "error in getting all cluster."
            return response

    return jsonify(response)

@app.route('/getClusterLogs', methods=['POST'])
def getClusterLogs():
    response = ''
    if request.headers['Content-Type'] == 'application/json':
        try:
            userId = request.json['userId']
            clusterName = request.json['clusterName']
            clusterManagement = ClusterManagementUI(userId, awsenv, appenv, reg)
            response = clusterManagement.getClusterLogs(userId,clusterName)
        except:
            response = "error in getting all cluster."
            return response

    return jsonify(response)

def findifadmin(clusterName, nid):
	try:
		clusterNameSplit=clusterName.split('-')
		nidincluster=clusterNameSplit[-2]
		if nidincluster==nid:
			return nid
		else:
			return nidincluster
	except Exception as e:
		print e
		return e

if __name__ == '__main__':
    # app.run(host='10.224.69.12',port=9945,debug=True)
    #context = ('backend.cert', 'backend.key')
    app.run(host='0.0.0.0', port=8080, threaded=True, debug=True)
