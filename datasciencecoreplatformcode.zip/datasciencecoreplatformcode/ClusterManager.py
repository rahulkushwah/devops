import boto3
import time
from datetime import datetime
from dateutil import tz
import random
import string
import json
import os
reg ='eu-west-1'
ec2_client = boto3.client('ec2')
iam_client = boto3.client('iam')
dynamodb_resource = boto3.resource('dynamodb')
#dataBase = 'intl-reg-data-science-user-data-db'
#table = dynamodb_resource.Table('intl-reg-data-science-user-db')
table = dynamodb_resource.Table('intl-reg-data-science-user-data-db')
ecs_client = boto3.client('ecs')
cft_client = boto3.client('cloudformation')
emr_client = boto3.client('emr')
log_client = boto3.client('logs')
dataScienceBaseBucket = 'intl-reg-data-science-platform'
dataScienceLogBucket = 'intl-reg-data-science-platform-log'
VPC="vpc-02034c65"
SubnetId="subnet-d754d08c"
key="data_science_platform_dev_pair"
AMI="ami-0dca662db75b46b76"
Sg="sg-039b42a25f330bb1f"
SgBasts="sg-7eeeb905"


#Added stopEc2function
#Edited runTask
#Added StartEc2Function
#Added getInstanceIp

class ClusterManager(object):

    
    @staticmethod
    def getData():
        print('ClusterManager :: ListDataBase :: Start')
        response = table.scan()

        print('ClusterManager :: ListDataBase :: End')
        return response['Items']


    @staticmethod
    # createCluster()
    def createCluster(clusterName):
        print('ClusterManager :: createCluster :: Start')
        response = ecs_client.create_cluster(
            clusterName=clusterName
        )
        print('ClusterManager :: createCluster :: End')
        return response


    @staticmethod
    def listCluster():
        print('ClusterManager :: listCluster :: Start')
        response = ecs_client.list_clusters()
        print('ClusterManager :: listCluster :: End')
        return response

    @staticmethod
    def getUserData(userID):
        print('ClusterManager :: getUserData :: Start')
        try:
            response = table.get_item(Key={'userId': userID})
            print('ClusterManager :: getUserData :: End')
            data = response['Item']
            return data
        except:
            data = ""
            return data

    @staticmethod
    def createE2Instance(nid,instanceType,ClusterName,iamInstanceProfileRole,ec2Cft,volumeSize,jupyterURL):
        try:

            templateBody = ec2Cft
            unique_identifier = ''.join(
                random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
            response = cft_client.create_stack(
                StackName='intl-reg-data-science-ecsnodesstack-' + nid + unique_identifier ,
                TemplateBody=templateBody,
                Parameters=[
                    {
                        'ParameterKey': 'Username',
                        'ParameterValue': nid
                    },
                    {
                        'ParameterKey': 'InstanceTypeName',
                        'ParameterValue': instanceType
                    },
                    {
                        'ParameterKey': 'ClusterName',
                        'ParameterValue': ClusterName
                    },
                    {
                        'ParameterKey': 'StackName',
                        'ParameterValue': 'intl-reg-data-science-ecsnodesstack-' + nid + unique_identifier
                    },
                    {
                        'ParameterKey': 'EC2SecurityGroupId',
                        'ParameterValue': Sg
                    },
                    {
                        'ParameterKey': 'EC2VolumeSize',
                        'ParameterValue': '50'
                    },
                    {
                        'ParameterKey': 'JupyterURL',
                        'ParameterValue': jupyterURL
                    },
                    {
                        'ParameterKey': 'EC2AddVolumeSize',
                        'ParameterValue': volumeSize
                    },
                    {
                        'ParameterKey': 'IamInstanceProfileRole',
                        'ParameterValue': iamInstanceProfileRole
                    },
                    {
                        'ParameterKey': 'AppName',
                        'ParameterValue': 'intl-reg-data-science-platform'
                    },
                    {
                        'ParameterKey': 'AppEnv',
                        'ParameterValue': 'dev'
                    },
                    {
                        'ParameterKey': 'AppRegion',
                        'ParameterValue': 'emea'
                    },
                    {
                        'ParameterKey': 'AppCountry',
                        'ParameterValue': 'reg'
                    },
                    {
                        'ParameterKey': 'Key',
                        'ParameterValue': key
                    }
                ],
                Capabilities=[
                    'CAPABILITY_IAM'
                ])
            print("creating stack...")
            waiter = cft_client.get_waiter('stack_create_complete')
            waiter.wait(StackName='intl-reg-data-science-ecsnodesstack-' + nid + unique_identifier)
            return response['StackId']

        except Exception as e:
            return e


    @staticmethod
    def getInstanceDeatils(stackId):
        print('ClusterManager :: getInstanceDeatils :: Start')
        try:
            response = cft_client.describe_stacks(
                StackName=stackId
            )
            stackOutputList = response['Stacks'][0]['Outputs']
            instanceDetails = {}
            for i in stackOutputList:
                if (i['OutputKey'] == "MasterInstanceId"):
                    instanceDetails['instanceId'] = i['OutputValue']
                if (i['OutputKey'] == "MasterInstanceIp"):
                    instanceDetails['instanceIp'] = i['OutputValue']
            print('ClusterManager :: getInstanceDeatils :: End')
            return instanceDetails
        except Exception as e:
            return e


    @staticmethod
    def createEc2Cft():
        try:
            unique_identifier = ''.join(
                random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
            Tags = [
                {
                    "Key": "Name",
                    "Value": {"Fn::Join": ["-", ["intl-reg-data-science-ecsEc2", {"Ref": "Username"}, unique_identifier]]}
                },
                {
                    "Key": "intl_region",
                    "Value": "emea"
                },
                {
                    "Key": "lm_applicationsupportemail",
                    "Value": "N/A"
                },
                {
                    "Key": "intl_country",
                    "Value": "reg"
                },
                {
                    "Key": "lm_app",
                    "Value": "intl-reg-data-science"
                },
                {
                    "Key": "lm_app_env",
                    "Value": "dev"
                },
                {
                    "Key": "lm_troux_uid",
                    "Value": "N/A"
                },
                {
                    "Key": "lm_sbu",
                    "Value": "INTL"
                },
                {
                    "Key": "Project",
                    "Value": "LM-GRM-WEM-DSPlatform"
                }
            ]
            cft = {}
            cft["Parameters"] = {}
            cft["Resources"] = {}
            cft["Outputs"] = {}
            cft["Parameters"]["InstanceTypeName"] = {
                "Description": "The type of instance to be launched",
                "Type": "String",
            }
            cft["Parameters"]["ClusterName"] = {
                "Description": "CLuster to be launched",
                "Type": "String",
            }
            cft["Parameters"]["Key"] = {
                "Description": "CLuster to be launched",
                "Type": "String",
            }

            cft["Parameters"]["Username"] = {
                "Description": "Provide the username to be tagged with each resource",
                "Type": "String",
            }
            cft["Parameters"]["StackName"] = {
                "Description": "Stack name value",
                "Type": "String",
                "MinLength": "1",
                "MaxLength": "100"
            }
            cft["Parameters"]["EC2SecurityGroupId"] = {
                "Type": "String"
            }
            cft["Parameters"]["EC2VolumeSize"] = {
                "Type": "String"
            }
            cft["Parameters"]["JupyterURL"] = {
                "Type": "String"
            }
            cft["Parameters"]["EC2AddVolumeSize"] = {
                "Type": "String",
                "Default": "50"
            }
            cft["Parameters"]["IamInstanceProfileRole"] = {
                "Type": "String"
            }
            cft["Parameters"]["AppName"] = {
                "Description": "The name of the application",
                "Type": "String",
                "AllowedPattern": "([a-z0-9\\-])+([a-z0-9])$"
            }
            cft["Parameters"]["AppEnv"] = {
                "Description": "The name of the application environment",
                "Type": "String",
                "AllowedValues": [
                    "dev",
                    "nonprod",
                    "prod"
                ],
                "Default": "dev",
                "ConstraintDescription": "Must be dev, nonprod, or prod"
            }
            cft["Parameters"]["AppRegion"] = {
                "Description": "Region the application resides",
                "Type": "String",
                "AllowedValues": [
                    "apac",
                    "emea",
                    "latam"
                ],
                "Default": "emea",
                "ConstraintDescription": "Select a region"
            }
            cft["Parameters"]["AppCountry"] = {
                "Description": "Country the application resides",
                "Type": "String",
                "AllowedValues": [
                    "br",
                    "cl",
                    "cn",
                    "co",
                    "ec",
                    "es",
                    "hk",
                    "ie",
                    "in",
                    "my",
                    "pt",
                    "ru",
                    "sg",
                    "th",
                    "tr",
                    "vn",
                    "ss",
                    "sec",
                    "reg"
                ],
                "Default": "reg",
                "ConstraintDescription": "Select a country"
            }
            UserData = {
                "Fn::Base64": {
                    "Fn::Join": [
                        "",
                        [
                            "#!/bin/bash -ve\n",
                            "exec &> /var/log/userdata.log\n",
                            "sudo yum install -y docker\n",
                            "sudo service docker start\n",
                            "mkdir newvolume\n",
                            "mkfs -t ext4 /dev/xvdb\n",
                            "mount /dev/xvdb /newvolume\n",
                            "echo '/dev/xvdb   /newvolume  ext4    defaults,nofail 0   0' >> /etc/fstab\n",
                            "mount -a\n",
                            "mkdir -p /newvolume/docker \n",
                            "echo '{\"graph\":\"/newvolume/docker\"}' >> /etc/docker/daemon.json \n",
                            "service docker restart \n",
                            "echo 'test'\n",
                            "sudo yum install -y ecs-init\n",
                            "sudo yum update -y ecs-init\n",
                            "echo ECS_CLUSTER=",
                            {
                                "Ref": "ClusterName"
                            },
                            ">> /etc/ecs/ecs.config\n",
                            "service sshd restart s\n",
                            "sudo service docker restart\n",
                            "sudo start ecs\n",

                            "# Signal success\n",
                            "/opt/aws/bin/cfn-signal -e 0 ",
                            "    --stack ",
                            {
                                "Ref": "StackName"
                            },
                            "    --resource ECSMasterNode",
                            "    --region ",
                            {
                                "Ref": "AWS::Region"
                            },
                            "\n",
                        ]
                    ]
                }
            }
            cft["Resources"]["VPC"] = {
                "Type": "Custom::ResourceLookup",
                "Version": "1.0",
                "Properties": {
                "ServiceToken": {"Fn::Join": [":", ["arn:aws:sns", {"Ref": "AWS::Region"}, "571458333875:custom-resource"] ] },
                "Resource": "VPC",
                "VpcEnv": {"Ref": "AppEnv"}
             }
            }
            cft["Resources"]["Subnet01"] = {
               "Type": "Custom::ResourceLookup",
               "Properties": {
               "Version": "1.0",
               "Resource": "Subnet",
               "ServiceToken": {"Fn::Join": [":", ["arn:aws:sns", {"Ref": "AWS::Region"}, "571458333875:custom-resource"] ] },
               "VpcId": {"Ref": "VPC"},
               "Name": "private",
               "Az": "1"
             }
            }
            cft["Resources"]["AMI01"] = {
                "Type": "Custom::ResourceLookup",
                "Version": "1.0",
                "Properties": {
                "Resource": "AMI",
                "ServiceToken": {"Fn::Join": [":", ["arn:aws:sns", {"Ref": "AWS::Region"}, "571458333875:custom-resource"] ] },
                "Name": "lm-base-amazon-linux",
                "Version": "latest"
             }
            }
            cft["Resources"]["CNAME"] = {
                "Type" : "Custom::ResourceDNS",
                "Version" : "1.0",
                "Properties" : {
                "Resource" : "CNAME",
                "ServiceToken" : { "Fn::Join" : [ ":", [ "arn:aws:sns", { "Ref" : "AWS::Region" }, "571458333875:custom-resource" ]]},
                "CNAME": {"Ref": "JupyterURL"},
                "IpAddress" : { "Fn::GetAtt" : [ "ECSMasterNode", "PrivateIp" ]}
             }
            }
            cft["Resources"]["ECSMasterNode"] = {"Type": "AWS::EC2::Instance",
                                                 "CreationPolicy": {
                                                     "ResourceSignal": {
                                                         "Count": 1,
                                                         "Timeout": "PT60M"
                                                     }
                                                 },
                                                 "Properties": {
                                                     "BlockDeviceMappings": [
                                                         {
                                                             "DeviceName": "/dev/xvda",
                                                             "Ebs": {
                                                                 "VolumeType": "gp2",
                                                                 "DeleteOnTermination": "true",
                                                                 "VolumeSize": {"Ref": "EC2VolumeSize"}
                                                             }
                                                         },
                                                         {
                                                             "DeviceName": "/dev/xvdb",
                                                             "Ebs": {
                                                                 "VolumeType": "gp2",
                                                                 "DeleteOnTermination": "true",
                                                                 "VolumeSize": {"Ref": "EC2AddVolumeSize"},
                                                                 "Encrypted":"true"
                                                                 }
                                                        }
                                                     ],
                                                     "KeyName": {"Ref": "Key"},
                                                     "InstanceInitiatedShutdownBehavior": "stop",
                                                     "NetworkInterfaces": [{
                                                         "AssociatePublicIpAddress": "false",
                                                         "DeviceIndex": "0",
                                                         "GroupSet": [{"Ref": "EC2SecurityGroupId"}],
                                                         "SubnetId": {"Ref": "Subnet01"}
                                                     }],
                                                     "ImageId": {"Ref": "AMI01"},
                                                     "InstanceType": {"Ref": "InstanceTypeName"},
                                                     "IamInstanceProfile": {"Ref": "IamInstanceProfileRole"},
                                                     "UserData": UserData,
                                                     "Tags": Tags
                                                 }
                                                 }
            cft["Outputs"]["MasterInstanceId"] = {
                "Description": "The Instance ID",
                "Value": {"Ref": "ECSMasterNode"}
            }
            cft["Outputs"]["CNAME"] = {
                "Description": "Cname of jupyter",
                "Value": {"Ref": "CNAME"}
            }
            cft["Outputs"]["MasterInstanceIp"] = {
                "Description": "Instance Ip Address",
                "Value": {"Fn::GetAtt": ["ECSMasterNode", "PrivateIp"]}
            }
            return json.dumps(cft, indent=3)
        except Exception as e:
            return e


    @staticmethod
    def createTaskDefinition(imagename, img, nid, nidpssd, role, portMappings,logGroupName):
        try:
            print('ClusterManager :: createTaskDefinition :: Start')
            unique_identifier = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
            logGroup = log_client.create_log_group(
                logGroupName=logGroupName)
            response=iam_client.get_role(RoleName='ecsTaskExecutionRole')
            executionRoleArn=response['Role']['Arn']
            response = ecs_client.register_task_definition(
                executionRoleArn=executionRoleArn,
                taskRoleArn=role,
                containerDefinitions=[
                    {
                        "logConfiguration": {
                            "logDriver": "awslogs",
                            "options": {
                                "awslogs-group": logGroupName,
                                "awslogs-region": reg,
                                "awslogs-stream-prefix": "ecs"
                            }
                        },
                        "entryPoint": [],
                        "portMappings": portMappings,
                        "command": [
                            nidpssd
                        ],
                        "cpu": 1000,
                        "environment": [],
                        'mountPoints': [
                        {
                        'sourceVolume': 'doc-vol',
                        'containerPath': '/demo',
                        'readOnly': False
                        }
                        ],
                        "memoryReservation": 4196,
                        "volumesFrom": [],
                        "image": img,
                        "readonlyRootFilesystem": False,
                        "name": 'intl-reg-data-science-task-cont-' + imagename + '-' + nid + '-' + unique_identifier
                    }
                ],
              volumes=[
                       {
            'name': 'doc-vol',
            'dockerVolumeConfiguration': {
                'scope': 'shared',
                'autoprovision': True,
                'driver': 'local'    
            }
        }
    ],
                family='intl-reg-data-science-taskdef-' + imagename + '-' + nid + '-' + unique_identifier,
                requiresCompatibilities=["EC2"]
            )
            print('ClusterManager :: createTaskDefinition :: END')
            return response['taskDefinition']['taskDefinitionArn']
        except Exception as e:
            return e



    @staticmethod
    def runTask(task_definition_arn, clusterName,taskName,instanceId):
        try:
            print('ClusterManager :: runTask :: Start')
            response = ecs_client.run_task(
                cluster=clusterName,
                taskDefinition=task_definition_arn,
                count=1,
                placementConstraints=[
                    {
                        'type': 'memberOf',
                        'expression': 'ec2InstanceId in ['+instanceId+']'
                    }
                ],
                launchType='EC2',
                group = taskName
            )
            #Should add a time delay
            flag = 0
            count = 0
            while flag == 0 and count<10:
                try:
                    waiter = ecs_client.get_waiter('tasks_running')
                    waiter.wait(cluster = clusterName, tasks=[response['tasks'][0]['taskArn']], WaiterConfig={'Delay': 25})
                    flag = 1
                except Exception as e:
                    print(e)
                    flag = 0
                count = count + 1    
            print('ClusterManager :: runTask :: END')
            return response['tasks'][0]['taskArn']
        except Exception as e:
            print(e)
            return e

    @staticmethod
    def describeTasks(clusterName, taskArn):
        try:
            response = ecs_client.describe_tasks(
                cluster=clusterName,
                tasks=[
                    taskArn,
                ]
            )
            return response
        except Exception as e:
            return e
    @staticmethod
    def deleteEc2ContainerInstance(stackId):
        try:
            response = cft_client.delete_stack(
                StackName=stackId)
            waiter = cft_client.get_waiter('stack_delete_complete')
            waiter.wait(StackName=stackId)
            return True
        except Exception as e:
            return False

    @staticmethod
    def stopEc2ContainerInstance(instanceId):
        try:
            response = ec2_client.stop_instances(
            InstanceIds=[
                instanceId
            ])
            waiter = ec2_client.get_waiter('instance_stopped')
            waiter.wait(InstanceIds=[instanceId])
            return True
        except Exception as e:
            return False

    @staticmethod
    def startEc2ContainerInstance(instanceId):
        try:
            response = ec2_client.start_instances(
            InstanceIds=[
                instanceId
            ])
            waiter = ec2_client.get_waiter('instance_status_ok')
            waiter.wait(InstanceIds=[instanceId])
            return True
        except Exception as e:
            return False

    @staticmethod
    def deleteTaskDefinition(taskDefinitionArn, logGroupName):
        try:
             response = log_client.delete_log_group(
                 logGroupName=logGroupName
             )
             response = ecs_client.deregister_task_definition(
                 taskDefinition=taskDefinitionArn
             )
        except Exception as e:
             return e
        return response

    @staticmethod
    def addTaskToDatabase(newUserId, email, username, arn, role, clusterName, taskList,emrClusters):
        try:
            response = table.put_item(
                Item={
                    'userId': newUserId,
                    'username': username,
                    'emailId': email,
                    'role': role,
                    'instanceProfile': arn,
                    'clusterName': clusterName,
                    'taskList': taskList,
                    'emrClusters': emrClusters
                }
            )
            print(response)
            created = True
            return created
        except Exception as e:
            created = False
            return created
    
    @staticmethod
    def createEmrCluster(Body, instanceTypeValue, nid, iamInstanceProfileRole, count):
        unique_identifier = ''.join(
            random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
        try:
            response = cft_client.create_stack(
                StackName='intl-reg-data-science-platform-emrstack-' + nid + unique_identifier,
                TemplateBody=Body,
                Parameters=[
                    {
                        'ParameterKey': 'Username',
                        'ParameterValue': nid
                    },
                    {
                        'ParameterKey': 'InstanceType',
                        'ParameterValue': instanceTypeValue
                    },
                    {
                        'ParameterKey': 'LogBucketName',
                        'ParameterValue': dataScienceLogBucket
                    },
                    {
                        'ParameterKey': 'KeyName',
                        'ParameterValue': key
                    },
                    {
                        'ParameterKey': 'UniqueId',
                        'ParameterValue': unique_identifier
                    },
                    {
                        'ParameterKey': 'AMIId',
                        'ParameterValue': AMI
                    },
                    {
                        'ParameterKey': 'Subnet',
                        'ParameterValue': SubnetId
                    },
                    {
                        'ParameterKey': 'IamInstanceProfileRole',
                        'ParameterValue': iamInstanceProfileRole
                    },
                    {
                        'ParameterKey': 'IamRole',
                        'ParameterValue': iamInstanceProfileRole
                    },
                    {
                        'ParameterKey': 'InstanceCount',
                        'ParameterValue': count
                    },
                    {
                        'ParameterKey': 'VPCId',
                        'ParameterValue': VPC
                    },
                    {
                        'ParameterKey': 'AppName',
                        'ParameterValue': 'intl-emea-data-science'
                    },
                    {
                        'ParameterKey': 'AppEnv',
                        'ParameterValue': 'dev'
                    },
                    {
                        'ParameterKey': 'AppRegion',
                        'ParameterValue': 'emea'
                    },
                    {
                        'ParameterKey': 'AppCountry',
                        'ParameterValue': 'reg'
                    },
                    {
                        'ParameterKey': 'LogBucketFolder',
                        'ParameterValue': nid
                    }
                ],
                Capabilities=[
                    'CAPABILITY_IAM'
                ],

                Tags=[
                    {
                        'Key': 'Project',
                        'Value': 'LM-GRM-WEM-DSPlatform'
                    }
                ])
            print("creating stack...")
            waiter = cft_client.get_waiter('stack_create_complete')
            waiter.wait(StackName='intl-reg-data-science-platform-emrstack-' + nid + unique_identifier)
            return response['StackId']

        except Exception as e:
            return e


    @staticmethod
    def stopTask(clusterName,taskArn):
      try:
          response = ecs_client.stop_task(
          cluster=clusterName,
          task=taskArn
          )
          waiter = ecs_client.get_waiter('tasks_stopped')
          waiter.wait(
          cluster=clusterName,
          tasks=[
              taskArn
          ])
          return 'Task Deletion done'
      except Exception as e:
         return e


    @staticmethod
    def deleteEmrCluster(stackId):
        try:
            response = cft_client.delete_stack(
                StackName=stackId)
            waiter = cft_client.get_waiter('stack_delete_complete')
            waiter.wait(StackName=stackId)
            return True
        except Exception as e:
            return False

    @staticmethod
    def describeEmrCluster(stackId):
        try:
            response = cft_client.describe_stacks(
                StackName=stackId
            )
            stackOutputList = response['Stacks'][0]['Outputs']
            emrDetails = {}
            for i in stackOutputList:
                if (i['OutputKey'] == "EMRMasterNodeDNS"):
                    emrDetails['masterdns'] = i['OutputValue']
            return emrDetails
        except Exception as e:
            return e

    @staticmethod
    def deleteEcsCluster(userId):
        try:
            response = ecs_client.delete_cluster(
                cluster='intl-reg-data-science-ecs-' + userId
            )
            return  response
        except Exception as e:
            return e

    @staticmethod
    def deleteRole(deleteUserId):
        try:
            response = cft_client.delete_stack(
                StackName='intl-reg-data-science-role-cft-' + deleteUserId)
            waiter = cft_client.get_waiter('stack_delete_complete')
            waiter.wait(StackName='intl-reg-data-science-role-cft-' + deleteUserId)
            return True
        except:
            return False

    @staticmethod
    def deleteUserFromDatabase(deleteUserId):
        try:
            response = table.delete_item(
                Key={
                    'userId': deleteUserId
                }
            )
            response = True
        except:
            response = False
        return response
    @staticmethod
    def getStartTime(instanceId):
        response = ec2_client.describe_instances(
            InstanceIds=[
                instanceId
            ]
        )
        return response['Reservations'][0]['Instances'][0]["LaunchTime"]

    @staticmethod
    def getStartTimeFromStack(stackId):
        response = cft_client.describe_stack_resources(
            StackName=stackId,
        )
        list = response['StackResources']
        for i in list:
            if i['LogicalResourceId'] == 'EMRCluster':
                startTime = i['Timestamp']
        return  startTime

    @staticmethod
    def getLogStreams(logGroup):
        response = log_client.describe_log_streams(
            logGroupName=logGroup
        )
        return response['logStreams'][0]['logStreamName']
    @staticmethod
    def getLogs(logGroup,LogGroupStream):
        response = log_client.get_log_events(
            logGroupName=logGroup,
            logStreamName=LogGroupStream,
            startFromHead=False
        )
        return response['events']

    @staticmethod
    def getCost(launchTime, price, nodes):
        time_without_zone_stamp = launchTime.replace(tzinfo=None)
        now = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        now = datetime.strptime(now, '%Y-%m-%d %H:%M:%S')
        duration = now - time_without_zone_stamp
        duration_in_s = int(duration.total_seconds())
        cost = duration_in_s * price * nodes
        return cost

    @staticmethod
    def converStartTimeToString(launchTime):
        return unicode(launchTime)

    @staticmethod
    def convertStringToStartTime(launchTime):
        datetime_object = datetime.strptime(launchTime, '%Y-%m-%d %H:%M:%S')
        return datetime_object
      
    @staticmethod
    def send_mail(nid,pssd,email,clusterName):
      os.system("echo Your jupyternotebook password is:  " +pssd+ " | mailx -S smtp=smtprelay.lmig.com -s "+ clusterName+" -r noreply@libertymutual.com " + email)
    
    @staticmethod
    def getClusterId(stackId):
      try:
          response = cft_client.describe_stack_resources(
              StackName=stackId
          )
          list = response['StackResources']
          for i in list:
              if i['LogicalResourceId'] == 'EMRCluster':
                  clusterId = i['PhysicalResourceId']
          return clusterId
      except Exception as e:
          print(e)
          return e
    
    @staticmethod
    def getMasterInstanceId(clusterId):
        try:
            response = emr_client.list_instances(
              ClusterId=clusterId,
              InstanceGroupTypes=[
                  'MASTER',
              ]
            )
            masterNodeInstanceId = response['Instances'][0]['Ec2InstanceId']
            return masterNodeInstanceId
        except Exception as e:
            print(e)
            return e

    @staticmethod
    def getNetworkInterfaceId(masterNodeInstanceId):
        try:
            response = ec2_client.describe_instances(
              InstanceIds=[
                  masterNodeInstanceId
              ]
            )
            networkInterfaceId=response['Reservations'][0]['Instances'][0]['NetworkInterfaces'][0]['NetworkInterfaceId']
            emrSecurityGroupId=response['Reservations'][0]['Instances'][0]['SecurityGroups'][0]['GroupId']
            return networkInterfaceId,emrSecurityGroupId
        except Exception as e:
            print(e)
            return e
      
    @staticmethod
    def addSecurityGroup(networkInterfaceId,emrSecurityGroupId):
        try:
            response = ec2_client.modify_network_interface_attribute(
                Groups=[
                    emrSecurityGroupId,
                    Sg
                ],
                NetworkInterfaceId=networkInterfaceId
            )
            return "Security Group Added"   
        except Exception as e:
            print(e)
            return e
          
    @staticmethod
    def updateTaskListItem(userId, taskName, taskItem):
        try:
            response = table.update_item(
                Key={
                    'userId': userId
                },
                UpdateExpression = "SET taskList.#taskName = :string",
                ExpressionAttributeNames = { "#taskName" : taskName },
                ExpressionAttributeValues = { ":string" : taskItem })
            return True
        except Exception as e:
            print(e)
            return False
          
    @staticmethod
    def updateEMRClustersItem(userId, emrName, emrItem):
        try:
            response = table.update_item(
                Key={
                    'userId': userId
                },
                UpdateExpression = "SET emrClusters.#emrName = :string",
                ExpressionAttributeNames = { "#emrName" : emrName },
                ExpressionAttributeValues = { ":string" : emrItem })
            return True
        except Exception as e:
            print(e)
            return False
          
    @staticmethod
    def deleteTaskListItem(userId, taskName):
        try:
            response = table.update_item(
                Key={
                    'userId': userId
                },
                UpdateExpression = "REMOVE taskList.#taskName",
                ExpressionAttributeNames = { "#taskName" : taskName }
            )
            return True
        except Exception as e:
            print(e)
            return False
          
    @staticmethod
    def deleteEMRClustersItem(userId, emrName):
        try:
            response = table.update_item(
                Key={
                    'userId': userId
                },
                UpdateExpression = "REMOVE emrClusters.#emrName",
                ExpressionAttributeNames = { "#emrName" : emrName }
            )
            return True
        except Exception as e:
            print(e)
            return False
      




