from ClusterManager import ClusterManager
import json
import time
from datetime import datetime
from datetime import tzinfo
import string
import random

dataScienceBaseBucket = 'intl-reg-data-science-platform'
dataScienceLogBucket = 'intl-reg-data-science-platform-log'
#dataBase = 'intl-reg-data-science-user-db'
dataBase = 'intl-reg-data-science-user-data-db'
class ClusterManagementUI(object):


    def __init__(self, username,awsenv,appenv,reg):
        self.username = username
        self.awsenv = awsenv
        self.appenv = appenv
        self.reg = reg

    # get all cluster information for the user
    def getClusterDetails(self,nId):
        res = {'headers' : [ 'Name', 'Cluster Type', 'Launch Time', 'Cost', 'Notebook Link','State','Nodes', 'volume(GB)', 'Friendly Name'],'label' : ['name','clusterType','launchTime','cost','notebookLink','State','Nodes','volumeSize','userClusterName']}
        response = ClusterManager.getUserData(nId)
        responseList = []
        if len(response) >0:
            emailId = response['emailId']
            userRole = response['role']
            role = response['instanceProfile']
            username = response['username']
            clusterName = response['clusterName']
            taskList = response['taskList']
            emrClusters = response['emrClusters']
            newtaskList = taskList
            newemrClusters = emrClusters
            if len (response['taskList'])>0:
                for key,val in response['taskList'].items():
                    data={}
                    data['name'] = key
                    data['clusterType'] =val['compute']
                    data['launchTime']=val['launchTime']
                    if val['state'].lower()=="running":
                        launchTime = ClusterManager.convertStringToStartTime(val['launchTime'])
                        totalCost=float(val['totalCost'])+ ClusterManager.getCost(launchTime, float(val['price']),1)
                    else:
                      totalCost=float(val['totalCost'])
                    data['cost'] = str(totalCost)
                    data['notebookLink']= val['notebookLink']
                    data['State'] = val['state']
                    data['Nodes'] = "1"
                    data['volumeSize'] = val['volumeSize']
                    data['userClusterName'] = val['userClusterName']
                    responseList.append(data)
            if len ((response['emrClusters']))>0:
                newemrClusters={}
                for key,val in response['emrClusters'].items():
                    data={}
                    data['name'] = key
                    data['clusterType'] =val['compute']
                    data['launchTime']=val['launchTime']
                    if val['state'].lower()=="running":
                        launchTime = ClusterManager.convertStringToStartTime(val['launchTime'])
                        totalCost=float(val['totalCost'])+ClusterManager.getCost(launchTime, float(val['price']),float(val['instanceCount']))
                    else:
                      totalCost=float(val['totalCost'])
                    data['cost'] = str(totalCost)
                    data['notebookLink']= val['notebookLink']
                    data['State']=val['state']
                    data['Nodes'] = val['instanceCount']
                    data['volumeSize'] = val['volumeSize']
                    data['userClusterName'] = val['userClusterName']
                    responseList.append(data)
            else:
                res['data']=[]
            res['data'] = responseList
        else:
            res['data'] = []
        return res


    def createECSCluster(self,workloadType,instanceType,instanceSize,image,volumeSize,userClusterName):
        images ={
            'jps': '634746942589.dkr.ecr.eu-west-1.amazonaws.com/intl-reg-data-science-platform-jsp',
            'jpr': '634746942589.dkr.ecr.eu-west-1.amazonaws.com/intl-reg-data-science-platform-jpr',
            'jprs' :'634746942589.dkr.ecr.eu-west-1.amazonaws.com/intl-reg-data-science-platform-jspr',
            'jprrs' : '634746942589.dkr.ecr.eu-west-1.amazonaws.com/intl-reg-data-science-platform-jprrs'}
        workloadList = []
        instanceTypeList = []
        with open('instanceTypeMap.json', 'r') as f:
            ec2Config = json.load(f)
        if workloadType.lower() == 'gpu':
            workloadList = ec2Config['Ec2-Instance-Type'][0][workloadType.lower()]
        else:
            workloadList = ec2Config['Ec2-Instance-Type'][1][workloadType.lower()]

        if instanceType.lower() == 'memory':
            instanceTypeList = workloadList[0][instanceType.lower()]
        else:
            instanceTypeList = workloadList[1][instanceType.lower()]
        for i in instanceTypeList:
            if (list(i)[0] == instanceSize.lower()):
                instanceTypeValue = i[instanceSize.lower()]['instanceType']
                hourPrice = i[instanceSize.lower()]['instanceHourCost']
                secPrice = i[instanceSize.lower()]['instanceSecCost']
                instanceCpu = i[instanceSize.lower()]['cpu']
                instanceMemory = i[instanceSize.lower()]['memory']
        userData = ClusterManager.getUserData(self.username)
        emailId = userData['emailId']
        userRole = userData['role']
        role = userData['instanceProfile']
        username = userData['username']
        clusterName = userData['clusterName']
        taskList = userData['taskList']
        emrClusters = userData['emrClusters']
        pssd = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
        portsList=[]
        if image == 'rr' or image == 'jprrs':
            nidpssd = self.username + " " + pssd
            portMappings = [
                {
                    "hostPort": 8888,
                    "protocol": "tcp",
                    "containerPort": 8888
                },
                {
                    "hostPort": 8787,
                    "protocol": "tcp",
                    "containerPort": 8787
                }
            ]
            portsList.append("8888")
            portsList.append("8787")
        else:
            nidpssd = pssd
            portMappings = [
                {
                    "hostPort": 8888,
                    "protocol": "tcp",
                    "containerPort": 8888
                }
            ]
            portsList.append("8888")
        ecsIdentifier = ''.join(random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
        taskName = 'intl-reg-data-science-ecs-'+ self.username +'-'+ ecsIdentifier    
        taskItem = {     "instanceType": instanceSize,
                                                          "compute": instanceType,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "state":"Creating",
                                                          "notebookLink": "NA",
                                                          "price": secPrice,
                                                          "launchTime": "NA",
                                                          "portsList" : portsList,
                                                          "totalCost": 0,
                                                          "volumeSize":volumeSize,
                                                          "userClusterName":userClusterName
                                    }
        ClusterManager.updateTaskListItem(self.username,taskName ,taskItem)
        ec2Cft = ClusterManager.createEc2Cft()
        jupyterURL = ecsIdentifier+'-'+self.appenv+'.jupyter.tardis.aws.lmig.com'
        stackId = ClusterManager.createE2Instance(self.username, instanceTypeValue, clusterName, role,ec2Cft,volumeSize,jupyterURL)
        instanceDetails = ClusterManager.getInstanceDeatils(stackId)
        launchTime = ClusterManager.getStartTime(instanceDetails['instanceId'])
        launchTime = launchTime.replace(tzinfo=None)
        launchTime = ClusterManager.converStartTimeToString(launchTime)        
        logGroupName = "/ecs/intl-reg-data-science-task-" + image + "-" + self.username + '-' + ecsIdentifier
        taskDefinitionArn = ClusterManager.createTaskDefinition(image, images[image], self.username, nidpssd, role, portMappings,logGroupName)
        # send_mail(nid,pssd)
        taskArn = ClusterManager.runTask(taskDefinitionArn, clusterName,taskName,instanceDetails['instanceId'])
        taskDescription = ClusterManager.describeTasks(clusterName, taskArn)
        taskDetails = {}
        taskDetails['status'] = taskDescription['tasks'][0]['lastStatus']
        taskDetails['startedAt'] = taskDescription['tasks'][0]['startedAt']
        taskDetails['group'] = taskDescription['tasks'][0]['group']
        if taskDetails['status'] != 'RUNNING':
            ClusterManager.deleteEc2ContainerInstance(stackId)
            ClusterManager.deleteTaskDefinition(taskDefinitionArn,logGroupName)
        else:
            links=''
            for port in portsList:
                links=links+"https://"+jupyterURL+":"+port+" "
            taskItem = {"IP": instanceDetails['instanceIp'],
                                              "instanceType": instanceSize, # small -- large
                                              "compute": instanceType, # cpu -- gpu
                                              "instanceTypeValue" : instanceTypeValue,
                                              "instanceId": instanceDetails['instanceId'],
                                              "notebookLink" : links,
                                              "portsList": portsList,
                                              "taskDefinition": taskDefinitionArn,
                                              "taskArn" :taskArn,
                                              "launchTime": launchTime,
                                              "state": taskDetails['status'],  # it is status of task
                                              "stackId" : stackId,
                                              "price": secPrice,  # What price to write
                                              "logGroupName": logGroupName,
                                              "totalCost": "0",
                                              "volumeSize":volumeSize,
                                              "userClusterName":userClusterName
                                              }
            if ClusterManager.updateTaskListItem(self.username, taskDetails['group'],taskItem):
                ClusterManager.send_mail(self.username,pssd,emailId,taskDetails['group'])
                response = "Task has been created."
            else:
                response = "Task creation failed."
        return response



    def createEMRCluster(self,workloadType, instanceType, instanceSize, instanceCount,volumeSize,userClusterName):
        with open('instanceTypeMap.json', 'r') as f:
            ec2Config = json.load(f)
        # Same Logic to find the Instance type from the map
        try:
            if workloadType.lower() == 'gpu':
                workloadList = ec2Config['Ec2-Instance-Type'][0][workloadType.lower()]
            else:
                workloadList = ec2Config['Ec2-Instance-Type'][1][workloadType.lower()]

            if instanceType.lower() == 'memory':
                instanceTypeList = workloadList[0][instanceType.lower()]
            else:
                instanceTypeList = workloadList[1][instanceType.lower()]
            for i in instanceTypeList:
                if (list(i)[0] == instanceSize.lower()):
                    instanceTypeValue = i[instanceSize.lower()]['instanceType']
                    hourPrice = i[instanceSize.lower()]['instanceHourCost']
                    secPrice = i[instanceSize.lower()]['instanceSecCost']
                    instanceCpu = i[instanceSize.lower()]['cpu']
                    instanceMemory = i[instanceSize.lower()]['memory']
            userData = ClusterManager.getUserData(self.username)
            emailId = userData['emailId']
            userRole = userData['role']
            role = userData['instanceProfile']
            username = userData['username']
            clusterName = userData['clusterName']
            taskList = userData['taskList']
            emrClusters = userData['emrClusters']
            unique_identifier = ''.join(
                random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
            emrname ='intl-reg-data-science-emr-' + self.username +'-'+ unique_identifier
            emrItem = {            "compute": instanceType,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceSize,
                                            "state":"Creating",
                                            "notebookLink": "NA",
                                            "price": secPrice,
                                            "totalCost": "0",
                                            "launchTime": "NA",
                                            "instanceCount": instanceCount,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                }
            ClusterManager.updateEMRClustersItem(self.username, emrname, emrItem)
            with open('EMRMain.json', 'r') as f:
                Body = json.load(f)
            Body = json.dumps(Body, indent=3)
            stackId = ClusterManager.createEmrCluster(Body, instanceTypeValue, self.username, role, instanceCount)
            emrDetails = ClusterManager.describeEmrCluster(stackId) #describe has to be done
            launchTime = ClusterManager.getStartTimeFromStack(stackId)
            launchTime = launchTime.replace(tzinfo=None)
            launchTime = launchTime.strftime("%Y-%m-%d %H:%M:%S")
            emrmasterdnssplit=emrDetails['masterdns'].split('-')
            finalip = emrmasterdnssplit[4]
            finaliplist = finalip.split('.')
            emrmasterip=emrmasterdnssplit[1]+'.'+emrmasterdnssplit[2]+'.'+emrmasterdnssplit[3]+'.'+finaliplist[0]
            links="https://"+emrmasterip+":9443"
            emrItem = { "IP": emrDetails['masterdns'],
                                     "compute": instanceType,
                                     "instanceType" : instanceSize,
                                     "instanceTypeValue": instanceTypeValue,
                                     "notebookLink": links,
                                     "state": "RUNNING",
                                     "price": secPrice,
                                     "launchTime": launchTime,
                                     "totalCost": "0",
                                     "instanceCount" : instanceCount,
                                     "stackId" :stackId,
                                     "volumeSize":volumeSize,
                                     "userClusterName":userClusterName

            }
            clusterId = ClusterManager.getClusterId(stackId)
            masterNodeInstanceId = ClusterManager.getMasterInstanceId(clusterId)
            networkInterfaceId,emrSecurityGroupId = ClusterManager.getNetworkInterfaceId(masterNodeInstanceId)
            ClusterManager.addSecurityGroup(networkInterfaceId,emrSecurityGroupId)
            if ClusterManager.updateEMRClustersItem(self.username, emrname, emrItem):
                response = "EMR cluster is created"
            else:
                response = "EMR cluster creation failed."
        except Exception  as e:
            response = e
        return response


    def startCluster(self,userId,clusterId):
        try:
            response =''
            userData = ClusterManager.getUserData(userId)
            emailId = userData['emailId']
            userRole = userData['role']
            role = userData['instanceProfile']
            username = userData['username']
            clusterName = userData['clusterName']
            taskList = userData['taskList']
            emrClusters = userData['emrClusters']
            if 'ecs' in clusterId:
                if taskList[clusterId]['state'].lower() == 'stopped':
                    instanceType = taskList[clusterId]['instanceType']
                    instanceTypeValue = taskList[clusterId]['instanceTypeValue']
                    compute = taskList[clusterId]['compute']
                    price = taskList[clusterId]['price']
                    totalCost = taskList[clusterId]['totalCost']
                    portsList = taskList[clusterId]['portsList']
                    logGroupName = taskList[clusterId]['logGroupName']
                    taskDefinitionArn = taskList[clusterId]['taskDefinition']
                    volumeSize = taskList[clusterId]['volumeSize']
                    userClusterName = taskList[clusterId]['userClusterName']
                    instanceId = taskList[clusterId]['instanceId']
                    IP = taskList[clusterId]['IP']
                    stackId = taskList[clusterId]['stackId']
                    taskItem = {"IP":IP,
                                                          "instanceType": instanceType,
                                                          "compute": compute,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "instanceId": instanceId,
                                                          "taskDefinition": taskDefinitionArn,
                                                          "state":"Starting",
                                                          "notebookLink": "NA",
                                                          "price": price,
                                                          "launchTime": "NA",
                                                          "portsList" : portsList,
                                                          "logGroupName": logGroupName,
                                                          "totalCost": totalCost,
                                                          "volumeSize":volumeSize,
                                                        "userClusterName":userClusterName,
                                                        "stackId":stackId
                                    }
                    ClusterManager.updateTaskListItem(self.username, clusterId,taskItem)
                    # Basically create a ec2 instance and get the details. Get stack Id first and the get instance details
                    # ec2Cft = ClusterManager.createEc2Cft()
                    # stackId = ClusterManager.createE2Instance(userId, instanceTypeValue, clusterName, role, ec2Cft,volumeSize)
                    started = ClusterManager.startEc2ContainerInstance(instanceId)
                    instanceDetails = {}
                    instanceDetails['instanceId'] = instanceId
                    instanceDetails['instanceIp'] = IP

                    launchTime = ClusterManager.getStartTime(instanceDetails['instanceId'])
                    launchTime = launchTime.replace(tzinfo=None)
                    launchTime = ClusterManager.converStartTimeToString(launchTime)
                    taskName=clusterId
                    taskArn = ClusterManager.runTask(taskDefinitionArn, clusterName, taskName,instanceDetails['instanceId'])
                    taskDescription = ClusterManager.describeTasks(clusterName, taskArn)
                    taskDetails = {}
                    taskDetails['status'] = taskDescription['tasks'][0]['lastStatus']
                    taskDetails['startedAt'] = taskDescription['tasks'][0]['lastStatus']
                    taskDetails['group'] = taskDescription['tasks'][0]['group']
                    if taskDetails['status'] != 'RUNNING':
                        ClusterManager.deleteEc2ContainerInstance(stackId)
                        ClusterManager.deleteTaskDefinition(taskDefinitionArn,logGroupName)
                        # Check for deletion status and return something valuable
                        print('Rollback error in Starting cluster')
                    else:
                        links = ''
                        for port in portsList:
                            links = links + "https://" + instanceDetails['instanceIp'] + ":" + port + " "
                        taskItem = {"IP": instanceDetails['instanceIp'],
                                                          "instanceType": instanceType,
                                                          "compute": compute,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "instanceId": instanceDetails['instanceId'],
                                                          "taskDefinition": taskDefinitionArn,
                                                          "taskArn": taskArn,
                                                          "notebookLink": links,
                                                          "launchTime": launchTime,
                                                          "portsList": portsList,
                                                          "state": taskDetails['status'],
                                                          "price": price,
                                                          "stackId": stackId,
                                                          "logGroupName": logGroupName,
                                                          "totalCost": totalCost,
                                                          "volumeSize":volumeSize,
                                                          "userClusterName":userClusterName
                                                          }
                        if ClusterManager.updateTaskListItem(self.username, taskDetails['group'],taskItem):  # Already There
                            response = "Task has been created."
                        else:
                            response = "Task creation failed."
                else:
                    response = "Cluster is already running"
            else:  # EMR
                if emrClusters[clusterId]['state'].lower() == "stopped":
                    instanceCount = emrClusters[clusterId]['instanceCount']
                    price = emrClusters[clusterId]['price']
                    totalCost = emrClusters[clusterId]['totalCost']
                    instanceType = emrClusters[clusterId]['instanceType']
                    compute = emrClusters[clusterId]['compute']
                    instanceTypeValue = emrClusters[clusterId]['instanceTypeValue']
                    volumeSize = emrClusters[clusterId]['volumeSize']
                    userClusterName = emrClusters[clusterId]['userClusterName']
                    emrname = clusterId
                    emrItem = {            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceType,
                                            "state":"Starting",
                                            "notebookLink": "NA",
                                            "price": price,
                                            "totalCost": totalCost,
                                             "launchTime": "NA",
                                            "instanceCount": instanceCount,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                }
                    ClusterManager.updateEMRClustersItem(self.username, clusterId, emrItem)
                    with open('EMRMain.json', 'r') as f:
                        Body = json.load(f)
                    Body=json.dumps(Body, indent=3)
                    stackId = ClusterManager.createEmrCluster(Body, instanceTypeValue, self.username, role, instanceCount)
                    emrDetails = ClusterManager.describeEmrCluster(stackId)  # describe has to be done
                    unique_identifier = ''.join(
                        random.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits) for _ in range(8))
                    launchTime = ClusterManager.getStartTimeFromStack(stackId)
                    launchTime = launchTime.replace(tzinfo=None)
                    launchTime = launchTime.strftime("%Y-%m-%d %H:%M:%S")
                    clusterId = ClusterManager.getClusterId(stackId)
                    masterNodeInstanceId = ClusterManager.getMasterInstanceId(clusterId)
                    networkInterfaceId,emrSecurityGroupId = ClusterManager.getNetworkInterfaceId(masterNodeInstanceId)
                    ClusterManager.addSecurityGroup(networkInterfaceId,emrSecurityGroupId)
                    emrmasterdnssplit=emrDetails['masterdns'].split('-')
                    finalip = emrmasterdnssplit[4]
                    finaliplist = finalip.split('.')
                    emrmasterip=emrmasterdnssplit[1]+'.'+emrmasterdnssplit[2]+'.'+emrmasterdnssplit[3]+'.'+finaliplist[0]
                    links="https://"+emrmasterip+":9443"
                    emrItem = {"IP": emrDetails['masterdns'],
                                            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "state": "RUNNING",
                                            "instanceType" : instanceType,
                                            "notebookLink": links,
                                            "price": price,
                                            "totalCost": totalCost,
                                            "launchTime": launchTime,
                                            "instanceCount": instanceCount,
                                            "stackId": stackId,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName

                                            }
                    if ClusterManager.updateEMRClustersItem(self.username, emrname, emrItem):  # Already There
                        response = "Start EMR Task has been created."
                    else:
                        response = "Start EMR Task has been creation failed."
                else:
                    resposne = "Cluster is already running"
        except Exception as e:
            print(e)
        return response



    def stopCluster(self,userId,clusterId):
      try:
        userData = ClusterManager.getUserData(userId)
        emailId = userData['emailId']
        userRole = userData['role']
        role = userData['instanceProfile']
        username = userData['username']
        clusterName = userData['clusterName']
        taskList = userData['taskList']
        emrClusters = userData['emrClusters']
        if "ecs" in clusterId:
            if taskList[clusterId]['state'].lower() == 'running':
                taskArn = taskList[clusterId]['taskArn']
                stackId = taskList[clusterId]['stackId']
                instanceType = taskList[clusterId]['instanceType']
                compute = taskList[clusterId]['compute']
                price = taskList[clusterId]['price']
                totalCost = taskList[clusterId]['totalCost']
                portsList = taskList[clusterId]['portsList']
                logGroupName = taskList[clusterId]['logGroupName']
                instanceTypeValue = taskList[clusterId]['instanceTypeValue']
                taskDefinitionArn = taskList[clusterId]['taskDefinition']
                launchTime = taskList[clusterId]['launchTime']
                volumeSize = taskList[clusterId]['volumeSize']
                userClusterName = taskList[clusterId]['userClusterName']
                links = taskList[clusterId]['notebookLink']
                instanceId = taskList[clusterId]['instanceId']
                IP = taskList[clusterId]['IP']
                taskItem = {"IP": IP,
                                                          "instanceType": instanceType,
                                                          "compute": compute,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "instanceId": instanceId,
                                                          "taskDefinition": taskDefinitionArn,
                                                          "state": "Stopping",
                                                          "notebookLink": links,
                                                          "price": price,
                                                          "launchTime": launchTime,
                                                          "portsList" : portsList,
                                                          "logGroupName": logGroupName,
                                                          "totalCost": totalCost,
                                                          "stackId": stackId,
                                                          "taskArn":taskArn,
                                                          "volumeSize":volumeSize,
                                                          "userClusterName":userClusterName
                                                          }
                ClusterManager.updateTaskListItem(self.username, clusterId,taskItem)
                launchTime = ClusterManager.convertStringToStartTime(launchTime)
                totalCost = str(float(totalCost) + ClusterManager.getCost(launchTime, float(price),float('1')))
                ClusterManager.stopTask(clusterName,taskArn)
                stopped = ClusterManager.stopEc2ContainerInstance(instanceId)  # Already Done
                if stopped:
                    taskItem = {"IP":IP,
                                                          "instanceType": instanceType,
                                                          "compute": compute,
                                                          "instanceId": instanceId,
                                                          "stackId" : stackId,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "taskDefinition": taskDefinitionArn,
                                                          "state": "Stopped",
                                                          "notebookLink": "NA",
                                                          "price": price,
                                                          "launchTime": "NA",
                                                          "portsList" : portsList,
                                                          "logGroupName": logGroupName,
                                                          "totalCost": totalCost,
                                                          "volumeSize":volumeSize,
                                                          "userClusterName":userClusterName
                                                          }
                    if ClusterManager.updateTaskListItem(self.username, clusterId,taskItem) : # Already There
                        response = "Task has been stopped."
                    else:
                      response = "Task stopping failed."
                else:  
                    print('Stop failed')
            else:
                response = "Cluster is already in Stopped State"
        else: # EMR
          if emrClusters[clusterId]['state'].lower() == 'running':
              stackId = emrClusters[clusterId]['stackId']
              compute = emrClusters[clusterId]['compute']
              instanceType = emrClusters[clusterId]['instanceType']
              instanceTypeValue = emrClusters[clusterId]['instanceTypeValue']
              price = emrClusters[clusterId]['price']
              totalCost = emrClusters[clusterId]['totalCost']
              instanceCount = emrClusters[clusterId]['instanceCount']
              volumeSize = emrClusters[clusterId]['volumeSize']
              userClusterName = emrClusters[clusterId]['userClusterName']
              launchTime = emrClusters[clusterId]['launchTime']
              emrItem = {            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceType,
                                            "state":"Stopping",
                                            "notebookLink": "NA",
                                            "price": price,
                                            "totalCost": totalCost,
                                             "launchTime": launchTime,
                                            "instanceCount": instanceCount,
                                            "stackId" : stackId,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                }
              ClusterManager.updateEMRClustersItem(self.username, clusterId, emrItem)
              launchTime = ClusterManager.convertStringToStartTime(launchTime)
              totalCost = str(float(totalCost) + ClusterManager.getCost(launchTime, float(price),float(instanceCount)))
              deleted = ClusterManager.deleteEmrCluster(stackId)
              if deleted:
                 emrItem = {
                                            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceType,
                                            "state": "Stopped",
                                            "notebookLink": "NA",
                                            "price": price,
                                            "totalCost": totalCost,
                                             "launchTime": "NA",
                                            "instanceCount": instanceCount,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                            }
              else:
                  response = 'delete failed'
              if ClusterManager.updateEMRClustersItem(self.username, clusterId, emrItem):
                  response = "Task has been stopped."
              else:
                  response = "Task stopping failed."
          else:
              response="Cluster is already in Stopped State"
      except Exception as e:
        print e
      return response


    def deleteCluster(self,userId,clusterId):
        userData = ClusterManager.getUserData(userId)
        emailId = userData['emailId']
        userRole = userData['role']
        role = userData['instanceProfile']
        username = userData['username']
        clusterName = userData['clusterName']
        taskList = userData['taskList']
        emrClusters = userData['emrClusters']
        response = ''
        if 'ecs' in clusterId:
            if taskList[clusterId]['state'].lower() == 'running' or taskList[clusterId]['state'].lower() == 'stopped':
                taskArn = taskList[clusterId]['taskArn']
                stackId = taskList[clusterId]['stackId']
                instanceType = taskList[clusterId]['instanceType']
                compute = taskList[clusterId]['compute']
                price = taskList[clusterId]['price']
                totalCost = taskList[clusterId]['totalCost']
                portsList = taskList[clusterId]['portsList']
                logGroupName = taskList[clusterId]['logGroupName']
                instanceTypeValue = taskList[clusterId]['instanceTypeValue']
                taskDefinitionArn = taskList[clusterId]['taskDefinition']
                launchTime = taskList[clusterId]['launchTime']
                links = taskList[clusterId]['notebookLink']
                volumeSize = taskList[clusterId]['volumeSize']
                userClusterName = taskList[clusterId]['userClusterName']
                taskItem = {
                                                          "instanceType": instanceType,
                                                          "compute": compute,
                                                          "instanceTypeValue" : instanceTypeValue,
                                                          "taskDefinition": taskDefinitionArn,
                                                          "state": "Deleting",
                                                          "notebookLink": links,
                                                          "price": price,
                                                          "launchTime": launchTime,
                                                          "portsList" : portsList,
                                                          "logGroupName": logGroupName,
                                                          "totalCost": totalCost,
                                                          "stackId": stackId,
                                                          "taskArn":taskArn,
                                                          "volumeSize":volumeSize,
                                                          "userClusterName":userClusterName
                                                          }
                ClusterManager.updateTaskListItem(self.username, clusterId,taskItem)
                ClusterManager.stopTask(clusterName, taskArn)
                ClusterManager.deleteTaskDefinition(taskDefinitionArn, logGroupName)
                deleted = ClusterManager.deleteEc2ContainerInstance(stackId)  # Already Done
                if deleted :
                    #taskList.pop(clusterId)
                    ClusterManager.deleteTaskListItem(self.username, clusterId)
                    print('Cluster Deleted')
                    response = 'Cluster Deleted'
                else:
                    print('delete failed')
                    response = 'delete failed'          
            else:
                print('Cluster Cant be deleted the state should be stopped or running')    
                response = "Cluster Cant be deleted the state should be stopped or running"
        else:  # EMR
            if emrClusters[clusterId]['state'].lower() =='running':
                stackId = emrClusters[clusterId]['stackId']
                compute = emrClusters[clusterId]['compute']
                instanceType = emrClusters[clusterId]['instanceType']
                instanceTypeValue = emrClusters[clusterId]['instanceTypeValue']
                price = emrClusters[clusterId]['price']
                totalCost = emrClusters[clusterId]['totalCost']
                instanceCount = emrClusters[clusterId]['instanceCount']
                launchTime = emrClusters[clusterId]['launchTime']
                volumeSize = emrClusters[clusterId]['volumeSize']
                userClusterName = emrClusters[clusterId]['userClusterName']
                emrItem = {            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceType,
                                            "state":"Deleting",
                                            "notebookLink": "NA",
                                            "price": price,
                                            "totalCost": totalCost,
                                             "launchTime": launchTime,
                                            "instanceCount": instanceCount,
                                            "stackId" : stackId,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                }
                ClusterManager.updateEMRClustersItem(self.username, clusterId, emrItem)
                deleted = ClusterManager.deleteEmrCluster(stackId)
                if deleted:
                    #emrClusters.pop(clusterId)
                    ClusterManager.deleteEMRClustersItem(self.username, clusterId)
                else:
                    print('delete failed')
                    response = 'delete failed'
            elif emrClusters[clusterId]['state'].lower() =='stopped':
                #emrClusters.pop(clusterId)
                instanceCount = emrClusters[clusterId]['instanceCount']
                price = emrClusters[clusterId]['price']
                totalCost = emrClusters[clusterId]['totalCost']
                instanceType = emrClusters[clusterId]['instanceType']
                compute = emrClusters[clusterId]['compute']
                instanceTypeValue = emrClusters[clusterId]['instanceTypeValue']
                launchTime = emrClusters[clusterId]['launchTime']
                volumeSize = emrClusters[clusterId]['volumeSize']
                userClusterName = emrClusters[clusterId]['userClusterName']
                emrname = clusterId
                emrItem = {            "compute": compute,
                                            "instanceTypeValue": instanceTypeValue,
                                            "instanceType":instanceType,
                                            "state":"Deleting",
                                            "notebookLink": "NA",
                                            "price": price,
                                            "totalCost": totalCost,
                                             "launchTime": "NA",
                                            "instanceCount": instanceCount,
                                            "volumeSize":volumeSize,
                                            "userClusterName":userClusterName
                                }
                ClusterManager.updateEMRClustersItem(self.username, clusterId, emrItem)
                ClusterManager.deleteEMRClustersItem(self.username, clusterId)
                print('Cluster Deleted')
                response = 'Cluster Deleted'
            else:
                print('Cluster Cant be deleted the state should be stopped or running')    
                response = "Cluster Cant be deleted the state should be stopped or running"
        return response

    def getAllCluster(self):
        res = {'headers': ['Name', 'Cluster Type', 'Launch Time' , 'Cost', 'Notebook Link','State','Nodes','volume(GB)', 'Friendly Name'],'label' : ['name','clusterType','launchTime','cost','notebookLink','State','Nodes','volumeSize','userClusterName']}
        response = ClusterManager.getData()
        responseList = []
        if len(response) > 0:
            for userData in response:
                    if len(userData['taskList']) > 0:
                        for key, val in userData['taskList'].items():
                            data = {}
                            data['name'] = key
                            data['clusterType'] = val['compute']
                            data['launchTime'] = val['launchTime']
                            if val['state'].lower()=="running":
                                launchTime = ClusterManager.convertStringToStartTime(val['launchTime'])
                                totalCost=float(val['totalCost'])+ ClusterManager.getCost(launchTime, float(val['price']),1)
                            else:
                                totalCost=float(val['totalCost'])
                            data['cost'] = str(totalCost)                            
                            data['notebookLink'] = val['notebookLink']
                            data['State'] = val['state']
                            data['Nodes'] = "1"
                            data['volumeSize'] = val['volumeSize']
                            data['userClusterName'] = val['userClusterName']
                            responseList.append(data)
                    if len((userData['emrClusters'])) > 0:
                        for key, val in userData['emrClusters'].items():
                            data = {}
                            data['name'] = key
                            data['clusterType'] = val['compute']
                            data['launchTime'] = val['launchTime']
                            if val['state'].lower()=="running":
                                launchTime = ClusterManager.convertStringToStartTime(val['launchTime'])
                                totalCost=float(val['totalCost'])+ClusterManager.getCost(launchTime, float(val['price']),float(val['instanceCount']))
                            else:
                                totalCost=float(val['totalCost'])
                            data['cost'] = str(totalCost)
                            data['notebookLink'] = val['notebookLink']
                            data['State'] = val['state']
                            data['Nodes'] = val['instanceCount']
                            data['volumeSize'] = val['volumeSize']
                            data['userClusterName'] = val['userClusterName']
                            responseList.append(data)
            res['data'] = responseList
        else:
            res['data'] = []
        return res

    def getLogs(self,userId):
        res = {'headers': ['Name']}
        response = ClusterManager.getUserData(userId)
        responseList = []
        if len(response) > 0:
            dataList = response
            if len(dataList) > 0:
                if len(dataList['taskList']) > 0:
                    for key, val in dataList['taskList'].items():
                        data = {}
                        data['name'] = key
                        responseList.append(data)
                else:
                    res['data'] = []
                res['data'] = responseList
            else:
                res['data'] = []
        else:
            res['data'] = []
        return res


    def getClusterLogs(self,userId,clusterName):
        userData = ClusterManager.getUserData(self.username)
        logGroupName = userData['taskList'][clusterName]['logGroupName']
        streamName = ClusterManager.getLogStreams(logGroupName)
        logs = ClusterManager.getLogs(logGroupName,streamName)
        response=''
        for data in logs:
            response= response+ data['message']
        return response










