import boto3
import urllib
reg ='eu-west-1'
client_iam = boto3.client('iam')
client_s3 = boto3.client('s3')
client_cft = boto3.client('cloudformation')
client_ecs = boto3.client('ecs')
dynamodb = boto3.resource("dynamodb")
#db='intl-reg-data-science-user-db'
db='intl-reg-data-science-user-data-db'
dataScienceBaseBucket = 'intl-reg-data-science-platform'
dataScienceLogBucket = 'intl-reg-data-science-platform-log'
VPC="vpc-02034c65"
SubnetId="subnet-d754d08c"
key="data_science_platform_dev_pair"
AMI="ami-0dca662db75b46b76"
Sg="sg-039b42a25f330bb1f"
SgBasts="sg-7eeeb905"

class UserManager(object):

    @staticmethod
    def folder_creation(newUserId):
        print('UserManager :: createFolder :: Start')
        bucketname = dataScienceBaseBucket
        folder = newUserId + '/'

        response = client_s3.put_object(
            Bucket=bucketname,
            Body='',
            Key=folder
        )
        print(response)
        print("UserManager :: createFolder :: END")
        return response


    @staticmethod
    def runRoleCft(stackName,value,roleName):
        print('UserManager :: runRoleCft :: Start')
        response = client_cft.create_stack(
            StackName=stackName,
            TemplateBody=value,
            Capabilities=['CAPABILITY_NAMED_IAM']
        )
        print(response)
        waiter = client_cft.get_waiter('stack_create_complete')
        waiter.wait(StackName=stackName)
        print('UserManager :: runRoleCft :: END')
        return roleName

    @staticmethod
    def ecsClusterCreation(newUserId,reg):
        print('IAMManager :: listRoles :: Start')
        try:
            response = client_ecs.create_cluster(
                clusterName='intl-reg-data-science-ecs-' + newUserId
            )
            return response['cluster']['clusterName']
        except Exception as e:
            return e

    @staticmethod
    def dataBasePut(newUserId, email, username, roleName, role, clusterName):
        print("in db")
        table = dynamodb.Table(db)
        response = table.put_item(
            Item={
                'userId': newUserId,
                'username': username,
                'emailId': email,
                'role': role,
                'instanceProfile': roleName,
                'clusterName': clusterName,
                'taskList': {},
                'emrClusters': {}
            }
        )
        if response!= '':
            return True
        else:
            return False


    @staticmethod
    def getAllUsers():
        table = dynamodb.Table(db)
        response = table.scan()
        res = {'headers': ['Name', 'Group'], 'label' : ['userName', 'group']}
        userList=[]
        for users in response['Items']:
            userDic={}
            userDic['userName'] = users['userId']
            userDic['group'] = users['role']
            userList.append(userDic)
        res['data'] = userList
        return res
