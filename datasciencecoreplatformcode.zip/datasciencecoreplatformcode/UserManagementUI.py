import ldap3
import ssl
import re
import json
from ClusterManager import ClusterManager

dataScienceBaseBucket = 'intl-reg-data-science-platform'
dataScienceLogBucket = 'intl-reg-data-science-platform-log'
globalFolder = 'n0000000'

from UserManager import UserManager

class UserManagementUI(object):



  def __init__(self, newUserId, awsenv, appenv, region):
        self.newUserId = newUserId
        self.awsenv = awsenv
        self.appenv = appenv
        self.region = region

  # create user
  def createFolder(self,newUserId):
      print('UserManagementUI :: createFolder :: Start')
      UserManager.folder_creation(newUserId)
      print('UserManagementUI :: createFolder :: END')




  def createRoleCft(self,bucketList, newUserId):
      try:
          s3listRead = []
          s3listWrite = []
          s3listDeny = []
          for i in range(0, len(bucketList)):
              if (bucketList[i]['permission']['read'] == True):
                  s3listRead.append('arn:aws:s3:::' + bucketList[i]['name'] + '/*')
              if (bucketList[i]['permission']['write'] == True):
                  s3listWrite.append('arn:aws:s3:::' + bucketList[i]['name'] + '/*')
              if (bucketList[i]['permission']['deny'] == True):
                  s3listDeny.append('arn:aws:s3:::' + bucketList[i]['name'] + '/*')
          stackName = 'intl-reg-data-science-role-cft-' + newUserId
          roleName = 'intl-reg-data-science-role-profile-' + newUserId
          policyName = 'intl-reg-data-science-policy-' + newUserId
          with open('RolesCFT.json', 'r') as f:
              value = json.load(f)
          if (len(bucketList) == 0):
              value['Resources']['InstanceProfileS3Access']['Properties']['InstanceProfileName'] = roleName
              value['Resources']['S3PutObjectFunctionRole']['Properties']['RoleName'] = roleName
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyName'] = policyName
              list = []
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  0]['Resource'] = ['arn:aws:s3:::' + dataScienceBaseBucket + '/' + globalFolder + '/*',
                                    'arn:aws:s3:::' + dataScienceBaseBucket + '/' + newUserId + '/*',
                                     'arn:aws:s3:::' + dataScienceLogBucket + '/*']
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  6]['Resource'] = 'arn:aws:s3:::'+ dataScienceBaseBucket
              list.append(value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                              'Statement'][0])
              list.append(value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                              'Statement'][4])
              list.append(value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                              'Statement'][5])
              list.append(value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                              'Statement'][6])
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                  'Statement'] = list

          else:
              value['Resources']['InstanceProfileS3Access']['Properties']['InstanceProfileName'] = roleName
              value['Resources']['S3PutObjectFunctionRole']['Properties']['RoleName'] = roleName
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyName'] = policyName
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  0][
                  'Resource'] = ['arn:aws:s3:::' + dataScienceBaseBucket + '/' + globalFolder + '/*',
                                 'arn:aws:s3:::' + dataScienceBaseBucket + '/' + newUserId + '/*',
                                  'arn:aws:s3:::' + dataScienceLogBucket + '/*']
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  6]['Resource'] = 'arn:aws:s3:::'+ dataScienceBaseBucket
              list = []
              list.append(
                  value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                      'Statement'][0])
              if len(s3listDeny)>0:
                value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  1][
                  'Resource'] = s3listDeny
                list.append(value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                          'Statement'][1])
              if len(s3listRead)>0:
                value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                      'Statement'][
                      2][
                      'Resource'] = s3listRead
                list.append(
                      value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                          'Statement'][2])

              if len (s3listWrite)>0:
                value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument']['Statement'][
                  3][
                  'Resource'] = s3listWrite
                list.append(
                      value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                          'Statement'][3])
              list.append(
                  value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                      'Statement'][4])
              list.append(
                  value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                      'Statement'][5])
              list.append(
                  value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                      'Statement'][6])
              value['Resources']['S3PutObjectFunctionRole']['Properties']['Policies'][0]['PolicyDocument'][
                  'Statement'] = list
          value = json.dumps(value, indent=3)

          response = UserManager.runRoleCft(stackName, value,roleName)
      except Exception as e:
          print (e)
      return response

  def createCluster(self,newUserId,reg):
      print('UserManagementUI :: createCluster :: Start')
      response = UserManager.ecsClusterCreation(newUserId,reg)
      print('UserManagementUI :: createCluster :: END')
      return response


  def addToDatabase(self,newUserId, email, username, roleName, role, clusterName):
      print('UserManagementUI :: addToDatabase :: Start')
      response = UserManager.dataBasePut(newUserId, email, username, roleName, role, clusterName)
      print('UserManagementUI :: addToDatabase :: END')
      return response

  def getAllUsers(self):
      print('UserManagementUI :: getAllUsers :: Start')
      response = UserManager.getAllUsers()
      print('UserManagementUI :: getAllUsers :: END')
      return response


  def deleteUser(self,deleteUserId):
      userData = ClusterManager.getUserData(deleteUserId)
      role = userData['instanceProfile']
      username = userData['username']
      clusterName = userData['clusterName']
      taskList = userData['taskList']
      emrClusters = userData['emrClusters']
      for i in taskList.values():
          try:
              taskArn = i['taskArn']
              stackId = i['stackId']
              taskDefinitionArn = i['taskDefinition']
              ClusterManager.stopTask(clusterName,taskArn)
              ClusterManager.deleteTaskDefinition(taskDefinitionArn)
              ClusterManager.deleteEc2ContainerInstance(stackId)
          except Exception as e:
              print(e)
      for i in emrClusters.values():
          stackId = i['stackId']
          ClusterManager.deleteEmrCluster(stackId)
          ClusterManager.deleteRole(deleteUserId)
          ClusterManager.deleteUserFromDatabase(deleteUserId)
      ClusterManager.deleteEcsCluster(deleteUserId)
      response = "User deleted successfully."
      return  response










